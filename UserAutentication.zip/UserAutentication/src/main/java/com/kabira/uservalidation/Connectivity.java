package com.kabira.uservalidation;

public interface Connectivity {
	
	public boolean isValid(User ref) ;


}
